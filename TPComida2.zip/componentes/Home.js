import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { useContext, useEffect, useState } from "react";
import { StyleSheet, View, Text } from "react-native-web";
import { FlatList } from "react-native";
import axios from "axios";
import CardPlato from "./CardPlato";
import { ContextTPComidas } from "../context/context";
import Busqueda from "./Busqueda";

const Stack = createNativeStackNavigator();

function Home() {
    const context = useContext(ContextTPComidas);

    useEffect(() => {
        axios.get("https://api.spoonacular.com/recipes/complexSearch?limit=30&apiKey=451ace4e62314779b69da982ba3fb92d")
        .then(response => {
            let platos = response.data.results;
            context.setCarta(platos);
        });
    }, []);

    return (
        <View style={styles.containerTodo}>
            <Busqueda />

            <View style={styles.containerPlatos}>
                <Text>Menu</Text>
                <Text>Health score: {context.promedioHealth()}</Text>
                <FlatList
                    data={context.menu}
                    renderItem={({item}) => <CardPlato plato={item} esMenu={true} />}
                    keyExtractor={item => item.id}/>
            </View>

            <View style={styles.containerPlatos}>
                <Text>Lista de la api</Text>
                
                <FlatList
                    data={context.carta}
                    renderItem={({item}) => <CardPlato plato={item} esMenu={false} />}
                    keyExtractor={item => item.id}/>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    containerTodo: {
        justifyContent: 'flex-start',
        alignItems: 'center',
    },
    containerPlatos: {
        display: "flex",
        alignItems: 'center',
        flexDirection: 'column',
    },
    containerListaPlatos: {
        display: "flex",
        flexFlow: "row wrap",
        alignItems: 'center',
    }
});

export default Home;