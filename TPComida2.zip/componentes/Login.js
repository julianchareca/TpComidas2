import { useState } from "react";
import { StyleSheet, Button, TextInput, View } from "react-native";
import axios from "axios";
import { useNavigation } from "@react-navigation/native";
import { SafeAreaView } from "react-native-web";

function Login() {
    const navigation = useNavigation();

    const [email, setEmail] = useState("");
    const [contraseña, setContraseña] = useState("");
    const [error, setError] = useState("");

    const EnviarDatosLogin = async () => {
        if (email === "" || contraseña === "") {
            setError("Usuario o contraseña vacios. Completa los campos para continuar");
        } else {
            axios.post("http://challenge-react.alkemy.org", { email: email, password: contraseña })
                .then(response => {
                    navigation.navigate("Home");
                })
                .catch(error => {
                    setError("Usuario o contraseña incorrectos");
                });
        }
    }

    return (
        <View style={styles.container}>

            <SafeAreaView>
                <TextInput placeholder="usuario" onChangeText={email => setEmail(email)} />
                <TextInput placeholder="Contraseña" secureTextEntry={true} onChangeText={c => setContraseña(c)} />
                <Button onPress={EnviarDatosLogin} title="Iniciar sesion"></Button>
            </SafeAreaView>

            <h2>{error}</h2>
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
});

export default Login;