import { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Login from './componentes/Login';
import Home from './componentes/Home';
import DetallePlato from './componentes/DetallePlato';
import { ContextTPComidas } from './context/context';

const Stack = createNativeStackNavigator();

export default function App() {
  const [auth, setAuth] = useState("");
  const [menu, setMenu] = useState([]);
  const [carta, setCarta] = useState([]);

  const contarPlatos = (vegano) => {
    let cant = 0;
    menu.forEach(plato => {
      if (plato.vegan == vegano) {
        cant = cant + 1;
      }
    })
    return cant;
  }

  const añadirPlato = (nuevoPlato) => {
    if (menu.lenth == 4) return;

    if (contarPlatos(nuevoPlato.vegan) == 2) return;

    setMenu([...menu, nuevoPlato]);
    return;
  }

  const eliminarPlato = (id) => {
    setMenu(menu.filter(plato => plato.id != id));
  }

  const promedioHealth = () => {
    if (menu.length === 0) return 0;

    let promedio = 0;
    menu.forEach(plato => {
      promedio = promedio + plato.healthScore
    });
    return promedio / menu.length;
  }

  return (
    <ContextTPComidas.Provider value={{ auth, setAuth, menu, setMenu, carta, setCarta, contarPlatos, añadirPlato, eliminarPlato, promedioHealth }}>
      <NavigationContainer>
        <Stack.Navigator>
          <Stack.Screen name="Login" component={Login} options={{ headerShown: false }} />
          <Stack.Screen name="Home" component={Home} options={{ headerShown: false }} />
          <Stack.Screen name="DetallePlato" component={DetallePlato} options={{ headerShown: false }} />
        </Stack.Navigator>
      </NavigationContainer>
    </ContextTPComidas.Provider>
  );
}