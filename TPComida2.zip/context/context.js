import { createContext } from "react";

const ContextTPComidas = createContext();

export {ContextTPComidas};